# ESP32 micropython BleUart

#### 介绍
适用于esp32上micropython固件的蓝牙串口服务模组

#### 软件架构
#### lib:
1. ble_advertising.py
2. BleUartService.py
#### example:
1. main.py

#### 安装教程

1.  上传ble_advertising.py，BleUartService.py文件到板端
2.  根据main.py编写自己的应用

#### 使用说明

1.  蓝牙串口服务使用的UUID如下：
    * 透传服务UUID(16位): fe00 (base uuid :00000000-0000-1000-8000-00805f9b34fb)
    * 透传服务TX特征UUID：fe01
    * 透传服务RX特征UUID：fe02
2.  注册接受中断回调函数（可选），处理蓝牙接受的消息
3.  注册蓝牙连接、断开连接回调函数（可选），处理连接或断开是需要执行的事件。
4.  蓝牙发送消息
    * BleUart.ble_write( "The light is on!\n\r", notify=True)
    * notify默认为False，即不通知主机，选择True，则会在发送消息时通知主机接受消息。


#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request


#### 码云特技

1.  使用 Readme\_XXX.md 来支持不同的语言，例如 Readme\_en.md, Readme\_zh.md
2.  码云官方博客 [blog.gitee.com](https://blog.gitee.com)
3.  你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解码云上的优秀开源项目
4.  [GVP](https://gitee.com/gvp) 全称是码云最有价值开源项目，是码云综合评定出的优秀开源项目
5.  码云官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6.  码云封面人物是一档用来展示码云会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
