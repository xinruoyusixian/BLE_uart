from machine import Pin
from BleUartService import BLEUart
import bluetooth
    
LED = Pin(32, Pin.OUT)

def demo():
    print("start run")
    #init bluetooth
    #透传服务UUID(16位): fe00 (base uuid :00000000-0000-1000-8000-00805f9b34fb)
    #透传服务TX特征UUID：fe01
    #透传服务TX特征UUID：fe02
    ble = bluetooth.BLE()
    BleUart = BLEUart(ble, name="MpyBleUart")  
    
    #bluetooth rx callback ：蓝牙接受回调函数
    def BleRxCallback(rxbuf):
        print("Callback rx:",rxbuf)
        if(rxbuf == b'ON'):                 
            LED.value(1)
            BleUart.ble_write( "The light is on!\n\r", notify=True)#蓝牙发送消息到主机且通知
        elif(rxbuf == b'OFF'):     
            LED.value(0)
            BleUart.ble_write( "The light is off!\n\r", notify=True)
            
    #蓝牙连接回调函数
    def BleConnectCallback():
        print("ble connected")
        
     #蓝牙断开连接回调函数
    def BleDisconnectCallback():
        print("ble disconnected")

    #注册蓝牙事件回调函数    
    BleUart.RegistCallback(RxCB=BleRxCallback, ConnectCB=BleConnectCallback, DisconnectCB=BleDisconnectCallback)
    
if __name__ == '__main__':
    demo()  
